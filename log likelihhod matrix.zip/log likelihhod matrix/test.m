function matrix = test(file,Matrix,nucleotides)
%a test function to check for a gene if it is from a eukaryotic or a prokaryotic cell
count=0;
sequence=read_file(file);
for i=1:length(sequence)-1
  for j=1:length(nucleotides)
      for k=1:length(nucleotides)
        if sequence(i)==nucleotides(j)&& sequence(i+1)==nucleotides(k)
            count=count+Matrix(j+1,k+1);%calculates the markov chain for the matrix, using the log likelihood matrix

        end
      end
  end
end

disp('The gene:')
disp(file)
if count>0
    disp('is a eukaryotic gene')
    fprintf('\n')
   
else
    disp('is a prokaryotic gene')
end

end