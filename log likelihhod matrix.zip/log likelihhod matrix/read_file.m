function sequence = read_file(text_file)
 fid = fopen(text_file);
sequence='';
tline = fgets(fid);
tline = fgets(fid);
while ischar(tline)
    sequence=strcat(sequence,tline);
    tline = fgets(fid);
end
 
end