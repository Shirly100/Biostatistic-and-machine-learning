human_gene=fastaread('human_gene.txt');%opens the human's gene
bacteria_gene=fastaread('bacteria_gene.txt');%opens the bacteria's gene


human_matrix = zeros(5,5) ;
bacteria_matrix = zeros(5,5) ;
nucleotides='ACGT';
for i=2:5
    %sets the titles cells for the matrixes:'A C G T'
    human_matrix(1, i)=nucleotides(i-1);
    human_matrix(i, 1)=nucleotides(i-1);
    bacteria_matrix(1, i)=nucleotides(i-1);
    bacteria_matrix(i, 1)=nucleotides(i-1);
   
end

%calculates the likelihood matrixes
likelihood_human_matrix=setMatrix(human_gene.Sequence,nucleotides,human_matrix);
likelihood_bacteria_matrix=setMatrix(bacteria_gene.Sequence,nucleotides,bacteria_matrix);

%sets the log likelihood matrix
Matrix=zeros(5,5);
for i=2:5
    Matrix(1, i)=nucleotides(i-1);
    Matrix(i, 1)=nucleotides(i-1);

   
end
%calculate the log likelihood matrix
 for i=2:length(Matrix)
     for j=2:length(Matrix)
         Matrix(i,j)=log2(likelihood_human_matrix(i,j)/likelihood_bacteria_matrix(i,j));
     end 
     
 end



%check for a gene if it is from a eukaryotic or a prokaryotic cell:

 test('human_insulin.txt',Matrix,nucleotides);
  test('prokaryotic_gene.txt',Matrix,nucleotides);
