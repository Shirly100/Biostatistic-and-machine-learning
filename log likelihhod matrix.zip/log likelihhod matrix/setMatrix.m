function matrix = setMatrix(sequence,nucleotides,matrix)
%function to find the likelihood matrix
counter=zeros(1,4);
%finds how many pairs of each nucleotide there are:
for i=1:length(sequence)-1
    for j=1:length(nucleotides)
        if sequence(i)==nucleotides(j)
        counter(1,j)=counter(1,j)+1;
        end
    
    end
end 

pairs =   {'AA', 'AC','AG','AT','CA','CC','CG','CT','GA','GC','GG','GT','TA','TC','TG','TT' };%all the possible pairs of nucleotides
values = zeros(1,16);

%finds the count of each pair:
for i=1:length(sequence)-1
    pair=strcat(sequence(i),sequence(i+1));
    for j=1:length(pairs)
        if pair==char(pairs(1,j))
            values(1,j)=values(1,j)+1;
        end
    end
        
end

%sets the map containers with the count of each pair
pairsMap = containers.Map(pairs,values);

%devides the pairs by the count of ALL the pairs with the same start.
%for example: AT/A_,GA/G
 for i = 1:length(pairsMap)
     for j=1:length(nucleotides)
         if pairs{i}(1)==nucleotides(j)
             values(i)=(values(i)/counter(1,j));
         end
        
    
     end
   
 end 

 %sets the matrix with the right values
 k=1;
 for i=2:length(matrix)
     for j=2:length(matrix)
         matrix(i,j)=values(k);
         k=k+1;
     end
   
     
     
 end
 


 end


